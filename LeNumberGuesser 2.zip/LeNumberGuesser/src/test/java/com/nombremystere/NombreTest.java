package com.nombremystere;


import org.junit.jupiter.api.Test;

public class NombreTest {
	
	@Test
	
	public void GuessNombreTest() {
		//Arrange
		
		//Act
		
		//Verity
	}
	

}
